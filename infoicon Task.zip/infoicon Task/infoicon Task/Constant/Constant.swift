//
//  Constant.swift
//
//  Created by Ritesh on 13/03/23.

enum Constant {
    enum API {
        static let productURL = "https://fakestoreapi.com/products"
    }
}
