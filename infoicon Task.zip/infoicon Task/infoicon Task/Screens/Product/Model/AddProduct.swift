//
//  AddProduct.swift
//
//  Created by Ritesh on 13/03/23.
//

import Foundation

struct AddProduct: Codable {
    var id: Int? = nil
    let title: String
}
